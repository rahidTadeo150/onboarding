import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';

class onBoarding extends StatefulWidget {
  const onBoarding({Key? key}) : super(key: key);

  @override
  State<onBoarding> createState() => _onBoarding();
}

class _onBoarding extends State<onBoarding> {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: IntroductionScreen(
      globalBackgroundColor: Color(0xff1e175e),
      pages: [
        PageViewModel(
          title: 'Bingung Cari Informasi Beasiswa?',
          body:
              'Tenang Langkah anda sudah benar. Yaps, Disini kami menyediakan beragam informasi',
          image: Image.asset(
            'image/vector_find_book.png',
            width: 350,
          ),
          decoration: const PageDecoration(
            titleTextStyle: TextStyle(
                fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
            bodyTextStyle: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w400, color: Colors.white),
            titlePadding: EdgeInsets.only(top: 30, left: 1, right: 1),
            bodyPadding: EdgeInsets.only(top: 20, left: 5, right: 5),
            imagePadding: EdgeInsets.only(top: 70),
          ),
        ),
        PageViewModel(
          title: 'We Are Up to Date',
          body: 'Kami mengupdate informasi yang beredar hanya untuk anda',
          image: Image.asset(
            'image/vector_cari_cari_bg.png',
            width: 350,
          ),
          decoration: const PageDecoration(
            titleTextStyle: TextStyle(
                fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
            bodyTextStyle: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w400, color: Colors.white),
            titlePadding: EdgeInsets.only(top: 30, left: 4, right: 4),
            bodyPadding: EdgeInsets.only(top: 20, left: 5, right: 5),
            imagePadding: EdgeInsets.only(top: 70),
          ),
        ),
        PageViewModel(
          title: 'Eksplor Pengalamanmu Sekarang juga',
          body:
              'Asah Kemampuan mu dan Percaya dirilah, ingat "Virtus Proven per Actum"',
          image: Image.asset(
            'image/kamu_tahu_bg.png',
            width: 350,
          ),
          decoration: const PageDecoration(
            titleTextStyle: TextStyle(
                fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
            bodyTextStyle: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w400, color: Colors.white),
            titlePadding: EdgeInsets.only(top: 30, left: 1, right: 1),
            bodyPadding: EdgeInsets.only(top: 20, left: 5, right: 5),
          ),
        ),
      ],
      showBackButton: false,
      showNextButton: true,
      showSkipButton: true,
      showDoneButton: true,
      skip: const Text('Lewati',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
      done: const Text('Yes, I Know',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
      next: const Icon(Icons.arrow_forward),
      onDone: () {},
      onSkip: () {},
    ));
  }
}
