import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:on_boarding/onboarding.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.black54));
  runApp(const MaterialApp(home: onBoarding()));
}
